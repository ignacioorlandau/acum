package acumuladores;

public class Acumuladores {

	/**
	 * Dada una matriz de enteros y un número, verifica si existe alguna fila 
	 * donde todos sus elementos sean múltiplos del número recibido por 
	 * parámetro.
	 * 
	 * Si la matriz está vacía o si el número no es positivo, devuelve falso.
	 * 
	 * @param mat
	 * @param num
	 * @return
	 */
	public boolean todosMultiplosEnAlgunaFila(int[][] mat, int num) { 

		// revisa que no estan vacias las matrices 
		if (mat == null || mat.length == 0 || num <= 0) {
			return false;
		}

		boolean existeFilaValida = false; 

		// recorre las matrices, primero por filas luego por columnas 
		for (int i = 0; i < mat.length; i++) {
			boolean todaFilaEsMultiplo = true; 

			for (int j = 0; j < mat[i].length; j++) {

				todaFilaEsMultiplo = todaFilaEsMultiplo && (mat[i][j] % num == 0);// ve que sean multiplos de num 
			}

			existeFilaValida = existeFilaValida || todaFilaEsMultiplo;
		}

		return existeFilaValida;
	}


	/**
	 * Dado 2 matrices se verifica si hay intersección entre las filas de cada
	 * matriz, fila a fila.
	 * 
	 * Si las matrices tienen distinta cantidad de filas o si alguna matriz 
	 * está vacía, devuelve falso.
	 * 
	 * @param mat1
	 * @param mat2
	 * @return
	 */
	public boolean hayInterseccionPorFila(int[][] mat1, int[][]mat2) { 

		// si estan vacias es false 
		if (mat1 == null || mat2 == null || mat1.length == 0 || mat2.length == 0) {
			return false;
		}

		// ve que el largo de las filas sea igual
		if (mat1.length != mat2.length) {
			return false;
		}

		//recore y compara las filas de mat1 y mat2, para encontrar intercecciones
		for (int f = 0; f < mat1.length; f++) {
			boolean interseccionEnFila = false;

			for (int m1 : mat1[f]) {
				for (int m2 : mat2[f]) {

					interseccionEnFila = interseccionEnFila || (m1 == m2) ;// si m1 y m2 son iguales hay interseccion

				}
			}


			if (!interseccionEnFila) return false ;
		}

		return true;

	}

	/**
	 * Dada una matriz y el índice de una columna, se verifica si existe alguna
	 * fila cuya suma de todos sus elementos sea mayor estricto que la suma de
	 * todos los elementos de la columna indicada por parámetro.
	 * 
	 * Si el índice de la columna es inválido o la matriz está vacía, devuelve 
	 * falso.
	 * 
	 * @param mat
	 * @param nColum
	 * @return
	 */
	public boolean algunaFilaSumaMasQueLaColumna(int[][] mat, int nColum) { 

		if (mat == null || mat.length == 0) {
			return false;
		}

		// Verifico que la columna sea válida
		if (nColum < 0 || nColum >= mat[0].length) {
			return false;
		}

		// suma los numeros de la columna 
		int sumaColumna = 0;
		for (int i = 0; i < mat.length; i++) {
			sumaColumna += mat[i][nColum];
		}

		// suma los numeros de las filas 
		for (int i = 0; i < mat.length; i++) {
			int sumaFila = 0;
			for (int j = 0; j < mat[i].length; j++) {
				sumaFila += mat[i][j];
			}

			if (sumaFila > sumaColumna) {//compara columna y filas
				return true; 
			}
		}

		return false;

	}

	/**
	 * Dadas 2 matrices, se verifica si hay intersección entre las columnas de
	 * cada matriz, columna a columna.
	 * 
	 * Si las matrices tienen distinta cantidad de columnas o alguna matriz 
	 * está vacía, devuelve falso. 
	 * 
	 * @param mat1
	 * @param mat2
	 * @return
	 */
	public boolean hayInterseccionPorColumna(int[][] mat1, int[][] mat2) {

		if (mat1 == null || mat2 == null || mat1.length == 0 || mat2.length == 0) {
			return false;
		}
		if (mat1[0].length != mat2[0].length) {
			return false; // deben tener igual cantidad de columnas
		}

		int columnas = mat1[0].length;

		// Recorremos columna por columna
		for (int c = 0; c < columnas; c++) {
			boolean hayInterseccion = false;

			// Recorremos filas de mat1 y mat2 para la columna c
			for (int i = 0; i < mat1.length; i++) {
				for (int j = 0; j < mat2.length; j++) {
					hayInterseccion = hayInterseccion || (mat1[i][c] == mat2[j][c]);
				}
			}

			
			if (!hayInterseccion) return false;
				
			
		}

		
		return true;
	}
	
}



